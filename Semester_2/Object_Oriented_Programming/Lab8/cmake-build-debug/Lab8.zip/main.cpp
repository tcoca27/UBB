#include <iostream>
#include <assert.h>
#include <string>

#include "UI.h"
using namespace std;

int test()
{
    TrenchCoat coat1=TrenchCoat("Opt","S",56,"abc.jpg");
    TrenchCoat coat2=TrenchCoat("Opt","S",56,"abc.jpg");
    TrenchCoat coat3=TrenchCoat("COpt","M",56,"abc.jpg");
    assert(coat1.getSize()=="S");
    assert(coat1.getName()=="Opt");
    assert(coat1.getPrice()==56);
    assert(coat1==coat2);
//    //InMemoryRepository repository{};
//    assert(repository.addCoat(coat1)==0);
//    assert(repository.addCoat(coat2));
//    assert(repository.addCoat(coat3)==0);
//    assert(repository.findCoatPosition("COpt")==1);
//    assert(repository.updateCoat("Opt", "D",88,"asd.d")==0);
//    assert(repository.removeCoat("Opt")==0);
//    TextFileRepository repository1("C:\\UBB\\c+\\Teme\\Lab5\\TrenchCoats.txt");
//    //assert(repository1.addCoat(coat3)==0);
//    assert(repository1.updateCoat("Opt","s",89,"s")==0);
//    repository1.saveFile();
    return 0;
}

int main() {
    test();
    TextFileRepository repository{};
    TextFileRepository shoppingList{};
    Controller controller(&repository,&shoppingList);
    UI ui{controller};
    ui.GetCommand();
    return 0;
}